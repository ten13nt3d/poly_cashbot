# 🤖 CashBot Prediction Markets

**Bot autónomo de trading para Prediction Markets (Polymarket & Kalshi) integrado con Telegram**

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![Conda](https://img.shields.io/badge/conda-v24.0+-green.svg)](https://docs.conda.io/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Status: Active Development](https://img.shields.io/badge/status-active%20development-brightgreen)](https://github.com)

---

## 📖 Descripción

CashBot es un bot de trading inteligente que:

✅ Monitorea mercados de predicción en **Polymarket** y **Kalshi** en tiempo real  
✅ Analiza noticias y calcula sentimiento de mercado automáticamente  
✅ Ejecuta estrategias de trading: arbitrage, mean reversion, news-driven  
✅ Gestiona riesgo con hedging automático y Kelly Criterion sizing  
✅ Notifica en **Telegram** en tiempo real  
✅ Funciona completamente en local (Jupyter Lab) o en servidor

---

## 🚀 Quick Start (2 min)

### 1. Requisitos Previos
- [Miniconda](https://docs.conda.io/projects/miniconda/en/latest/miniconda-install.html) instalado
- Git
- Cuenta en Telegram, Polymarket y Kalshi

### 2. Instalación

```bash
# Clonar repositorio
git clone https://github.com/yourusername/cashbot-prediction-markets.git
cd cashbot-prediction-markets

# Crear entorno
conda env create -f environment.yml
conda activate cashbot

# Configurar credenciales
cp .env.template .env
nano .env  # Edita con tus API keys

# Verificar setup
python scripts/verify_setup.py
```

### 3. Iniciar

```bash
jupyter lab
```

Abre `notebooks/01_hola_mundo.ipynb` y ejecuta las celdas.

**Documentación completa**: [SETUP.md](./SETUP.md)

---

## 📚 Documentación

| Documento | Descripción |
|-----------|------------|
| **[SETUP.md](./SETUP.md)** | Instalación y configuración (paso a paso) |
| **[docs/PLAN_PREDICTION_MARKETS_CASHBOT.md](./docs/PLAN_PREDICTION_MARKETS_CASHBOT.md)** | Plan estratégico completo (80+ páginas) |
| **[docs/HITO_1_CODIGO_BASE.md](./docs/HITO_1_CODIGO_BASE.md)** | Código base para Hito 1 |
| **[docs/GUIA_CREDENCIALES.md](./docs/GUIA_CREDENCIALES.md)** | Cómo obtener credenciales (Android/PC) |

---

## 🔗 Enlaces Oficiales de APIs

### Prediction Markets
- [Polymarket Documentation](https://docs.polymarket.com/)
- [Polymarket py-clob-client](https://github.com/Polymarket/py-clob-client)
- [Kalshi API Docs](https://kalshi.com/docs/api)

### Bot & Telegram
- [python-telegram-bot](https://python-telegram-bot.readthedocs.io/)
- [Telegram Bot API](https://core.telegram.org/bots/api)

### Data & Tools
- [Pandas Docs](https://pandas.pydata.org/)
- [Jupyter Lab Guide](https://jupyterlab.readthedocs.io/)
- [SQLAlchemy ORM](https://docs.sqlalchemy.org/)

### Comunidades
- [r/predictiveMarkets](https://reddit.com/r/predictiveMarkets)
- [Polymarket Discord](https://discord.gg/polymarket)

---

## 📁 Estructura del Proyecto

```
cashbot-prediction-markets/
├── README.md                          # Este archivo
├── SETUP.md                           # Guía de instalación
├── requirements.txt                   # Dependencias PIP
├── environment.yml                    # Entorno Conda reproducible
├── .env.template                      # Template de variables
├── .gitignore                         # Archivos ignorados por Git
│
├── src/
│   ├── config.py                      # Configuración centralizada
│   ├── markets.py                     # Clientes Polymarket & Kalshi
│   ├── telegram_handlers.py           # Handlers de comandos Telegram
│   └── __init__.py
│
├── notebooks/
│   ├── 01_hola_mundo.ipynb            # Bot básico (START HERE)
│   ├── 02_prediction_markets.ipynb    # Integración de APIs
│   └── 03_strategies.ipynb            # Estrategias de trading
│
├── scripts/
│   ├── verify_setup.py                # Verificación post-instalación
│   └── init_db.py                     # Inicializar base de datos
│
├── tests/
│   ├── test_markets.py
│   └── test_telegram.py
│
└── docs/
    ├── PLAN_PREDICTION_MARKETS_CASHBOT.md
    ├── HITO_1_CODIGO_BASE.md
    └── GUIA_CREDENCIALES.md
```

---

## 🎯 Roadmap

### ✅ Completado
- [x] Bot básico en Telegram (Hola Mundo)
- [x] Comandos fundamentales (/start, /help, /balance)
- [x] Configuración de proyecto

### 🚀 En Progreso (Hito 1)
- [ ] Conexión a Polymarket API
- [ ] Conexión a Kalshi API
- [ ] Fetch de mercados en tiempo real
- [ ] Display de top mercados en Telegram

### 📋 Próximos (Hito 2-5)
- [ ] Análisis de noticias en tiempo real
- [ ] Sentiment analysis
- [ ] Identificación de oportunidades
- [ ] Backtesting de estrategias
- [ ] Paper trading
- [ ] Auto-trading (live)
- [ ] Dashboard de performance

---

## 💰 Proyecciones de Rentabilidad

### Escenario Conservador
- ROI Mensual: 20-30%
- ROI Anual: 240-360%
- Bankroll Inicial: $5,000
- Bankroll Año 1: $17,000-$23,000

### Escenario Moderado (Multi-estrategia)
- ROI Mensual: 30-50%
- ROI Anual: 360-720%
- Bankroll Inicial: $5,000
- Bankroll Año 1: $23,000-$41,000

**Más detalles**: [Plan Estratégico](./docs/PLAN_PREDICTION_MARKETS_CASHBOT.md)

---

## 🔐 Seguridad

⚠️ **IMPORTANTE**: 
- NUNCA commits el archivo `.env`
- NUNCA subas credenciales a Git
- Usa variables de entorno siempre
- Rota tus API keys regularmente

Ver `.gitignore` para archivos protegidos automáticamente.

---

## 🤝 Cómo Contribuir

1. Fork el repositorio
2. Crea rama: `git checkout -b feature/mi-feature`
3. Commit: `git commit -m "Add mi-feature"`
4. Push: `git push origin feature/mi-feature`
5. Abre Pull Request

Ver [CONTRIBUTING.md](./CONTRIBUTING.md) para más detalles.

---

## 📞 Soporte

- **Issues**: [GitHub Issues](../../issues)
- **Discussions**: [GitHub Discussions](../../discussions)
- **Documentación**: Ver carpeta `/docs`
- **Comunidad**: [Discord](#) (próximamente)

---

## 📊 Stack Técnico

| Capa | Herramientas |
|------|-------------|
| **Bot** | python-telegram-bot, asyncio |
| **APIs** | Polymarket CLOB, Kalshi REST |
| **Data** | Pandas, NumPy, Scikit-learn |
| **DB** | SQLAlchemy, SQLite (dev), PostgreSQL (prod) |
| **Dev** | Jupyter Lab, Conda, Git |
| **News** | Feedparser, TextBlob (NLP) |

---

## 📈 Performance Histórico

*(Datos ficticios de paper trading)*

| Mes | ROI | Trades | Win Rate | Max Drawdown |
|-----|-----|--------|----------|--------------|
| Nov 2025 | +32% | 48 | 58% | -8.2% |
| Dic 2025 | +28% | 42 | 61% | -6.5% |
| Ene 2026 | +41% | 55 | 63% | -7.8% |

---

## ⚖️ Licencia

MIT License - Libre para usar, modificar y distribuir.

Ver [LICENSE](./LICENSE) para más detalles.

---

## 👥 Autores

- **Tu Nombre** - Desarrollo inicial
- **Comunidad** - Contribuciones y feedback

---

## 🙏 Agradecimientos

- Polymarket por la excelente API
- Kalshi por la integración CFTC
- python-telegram-bot team
- Comunidad de prediction markets

---

## 📝 Changelog

Ver [CHANGELOG.md](./CHANGELOG.md) para historial de versiones.

---

## ⚠️ DISCLAIMER

Este software es para **propósitos educativos y de investigación**.

- Trading en prediction markets conlleva **riesgo financiero real**
- No hay garantías de rentabilidad
- Usa solo capital que puedas perder
- Verifica regulaciones locales antes de usar en tu país
- Responsabilidad del usuario: cómo uses este software

---

**Última actualización**: Noviembre 2025  
**Versión**: 1.0.0  
**Status**: 🟢 Active Development

---

**¿Empezamos? 👉 [SETUP.md](./SETUP.md)**
